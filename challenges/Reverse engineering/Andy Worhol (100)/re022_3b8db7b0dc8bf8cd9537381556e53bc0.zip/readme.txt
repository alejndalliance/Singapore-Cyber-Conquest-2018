These binaries are functionaly the same.  One built for Windows, the other for Linux (Ubuntu).  

You don't need to run them, but you can if you like

